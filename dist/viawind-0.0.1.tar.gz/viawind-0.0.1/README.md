## Open-source Python Package development for Visual Impact Assessment (VIA) of Onshore Wind Turbines
Chinna Subbaraya Siddharth Ramavajjala<sup>1</sup>
Department of Geography, University of Wisconsin - Madison
Madison, Wisconsin, United States of America 

### Adopted GIS Workflow (Palmer 2022)
<img src="https://github.com/Sidrcs/Visual_Impact_Assessment/blob/main/Graphics/GIS_Workflow.png?raw=true">
 
