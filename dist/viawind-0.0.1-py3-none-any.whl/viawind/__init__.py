from .wind import CalcVisualImpact
